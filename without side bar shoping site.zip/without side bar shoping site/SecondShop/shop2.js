let products=[

    {
        name:"White T shirt",
        size:"L",
        color:"brown",
        price:1500,
        image:"image1.jpg",
        description:"Good Looking T shirt"
    },
    {
        name:"White T shirt",
        size:"L",
        color:"white",
        price:1500,
        image:"image2.jpg",
        description:"Good Looking T shirt"
    },
    {
        name:"White T shirt",
        size:"L",
        color:"white",
        price:1500,
        image:"image3.jpg",
        description:"Good Looking T shirt"
    },
    {
        name:"black T shirt",
        size:"L",
        color:"black",
        price:1500,
        image:"image4.jpeg",
        description:"Good Looking Blazer"
    },
    {
        name:"White T shirt",
        size:"L",
        color:"white",
        price:1500,
        image:"image5.jpeg",
        description:"Good Looking T shirt"
    },
    {
        name:"White T shirt",
        size:"L",
        color:"gray",
        price:1500,
        image:"image6.jpeg",
        description:"Long pink shirt"
    }


]



function displayproduct(productsData){

    let producstStr="";
    productsData.forEach(function(product){
        let {name,image,color,description,price,size}=product;
        producstStr+=`<div class="product">
        <div class="productImg">
            <img src="image/${image}" width="100%">
        </div>
        <h3>${name}</h3>
        <p>Price:${price}</p>
        <p>Size:${size}</p>
        <p>Color:${color}</p>
        <p>${description}</p>
        <p> 
            <button>Add To Cart</button>
        </p>
    </div>`;
    })
    document.getElementById("productwrapper").innerHTML=producstStr;
}
displayproduct(products);


 function searchproduct(searchvalue){
        // let inputvalue=document.getElementById("search").value;
        // document.getElementById("demo").innerHTML=inputvalue;
      let searchdproduct=  products.filter(function(product,index){
        let productString=product.name+" "+product.color+" "+product.description;
            return productString.toUpperCase().indexOf(searchvalue.toUpperCase())!=-1;
        });

        displayproduct(searchdproduct);


}



// function searchproduct(searchValue){
//     let searchProduct=products.filter(function(product,index){
//         let productString=product.name+" "+product.color+" "+product.description;
//         return productString.toUpperCase().indexOf(toUpperCase().searchValue)!=-1;

//     })
//     displayproduct(searchProduct);

// }
//just practise
// function displayproduct(productsData){

//     let productStr="";
// productsData.forEach(function(product){
//     let {image,color,size,price,name,description}=product;
//     productStr+=`<div class="product">
//     <div class="productImg">
//     <img src="image/${image}">
// </div>
// <h3>${name}</h3>
// <p>size:${size}</p>
// <P>color:${color}</P>
// <p>price:${price}</p>
// <P>${description}</P>
// <p>
//     <button>Add to cart</button>
// </p>

// </div>

// `
// });
// document.getElementById("productwrapper").innerHTML=productStr;
// }
// displayproduct(products);










